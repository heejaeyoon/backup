/**
 * 
 */
/**
 * @author admin
 *
 */
module projact1 {
}