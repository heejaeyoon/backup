package bus;

public class StartMain {
	
	public static void main(String[] args) {
		LoginMain.main(null);  //첫 로그인 화면 접속
	}
}
