package chap01;

public class Test3 {

	public static void main(String[] args) {
		int i = 0;
		for(; i < 10; i++) {
			System.out.println(i);
		}
		System.out.println("==>"+i);
	}

}
