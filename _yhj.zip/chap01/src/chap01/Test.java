package chap01;

public class Test {
	public static void main(String[] args ) {
		int a = 10;
		System.out.println(a );
		if(true) {
			System.out.println("ok");
		}
		
		
		
	}
}
		
		
		
		
	
