package chap02;


public class Student {

		String name = "홍길동"; //필드 
		static int age = 10;
		void print() {
			System.out.println("test");
		}
		
	}


