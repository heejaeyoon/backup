package chap02;

public class ForeEx1 {

	public static void main(String[] args) {
		int sum = 0;
		int i=1;
		while (i<=100) {
				sum = sum + 1;
				i++;
		} 
		System.out.println(sum);
	}
}

