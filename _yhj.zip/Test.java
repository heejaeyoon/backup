public class Test{
	public static void main(String[] ar) {
		System.out.println("Test");
	}
}