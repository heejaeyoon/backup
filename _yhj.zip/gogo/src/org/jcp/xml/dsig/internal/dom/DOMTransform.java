package org.jcp.xml.dsig.internal.dom;

public class DOMTransform {

}
