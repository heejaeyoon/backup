package gogo;

public class Member {
	int id;
	String loginId;
	String loginPw;
	String name;
	
	public Member(int id, String loginId, String loginPw, String name) {
		this.id = id;
		this.loginId = loginId;
		this.loginPw = loginPw;
		this.name = name;
	}
}