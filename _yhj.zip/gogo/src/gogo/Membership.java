package gogo;

public class Membership {

		String name;
		int phoneNumber;
		int point;
	
		Membership(String name, int phoneNumber, int point){
			this.name = name;
			this.phoneNumber = phoneNumber;
			this.point = point;
		}
		
	}

