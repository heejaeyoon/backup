/**
 * 
 */
/**
 * @author admin
 *
 */
module gogo2 {
}