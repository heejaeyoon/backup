package chap03;

class Car {
	int num;
	String str;
	
//	Car(int number){
//		
//	}
//	Car() {
//
//	}
}
	
		
		

