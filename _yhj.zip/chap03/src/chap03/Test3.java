package chap03;

public class Test3 {
	public static void main() {

		String[] aa = { "1", "2", "3", "4"};
		System.out.println(aa.length);
		for (int i = 0; i < aa.length; i++) {
			System.out.println(aa[i]);
//				int tt = aa[i] + 1;
			System.out.println(aa[i]+1);
		}

	}

}
