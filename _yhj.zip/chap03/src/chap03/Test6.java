package chap03;

public class Test6 {

	public static void main(String[] args) {
		String[] strArray = { "김밥", "라면", "자장면", "볶음밥", "잔치국수" };

		for (String food : strArray) {
			System.out.println(food);
		}
	}
}
