package chap03;

public class CarEx {

	public static void main(String[] args) {
		Car car = new Car(30);
		car.num = 40;
		car.str = "Test";
		String str = new String("연습");
		int num;
	}

}
