/**
 * 
 */
/**
 * @author admin
 *
 */
module gogo3 {
}