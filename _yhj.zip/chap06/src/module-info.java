/**
 * 
 */
/**
 * @author admin
 *
 */
module chap06 {
}