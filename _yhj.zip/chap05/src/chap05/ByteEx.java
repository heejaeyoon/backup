package chap05;

public class ByteEx {

	public static void main(String[] args) {
		boolean play = true;
		System.out.println(!play);
		System.out.println(1!=2);
		
	}

}
