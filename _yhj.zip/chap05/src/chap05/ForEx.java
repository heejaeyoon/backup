package chap05;

import java.util.Iterator;

public class ForEx {

	public static void main(String[] args) {
		int[] values = {3,5,6,7,8};
		
		for (int val : values) {
			System.out.println(val);
		}
//		for (int = 0; i<values.length; i++ ) {
//			System.out.println(values[i]);
		}
	

}
